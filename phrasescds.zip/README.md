# phrasescds
Site pour les boulettes chouquettes du CDS

# phrasescds 1.1.0
Site pour les boulettes chouquettes du CDS

# Requis
- Composer : https://getcomposer.org/doc/00-intro.md
Ou utiliser 1.1.0.zip pour un package complet
- Extension PDO SQlite PHP

# Installation  des dépendances
```
composer install
```

